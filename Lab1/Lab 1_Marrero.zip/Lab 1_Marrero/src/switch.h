// Author: Mason Marrero  
// Net ID: masonmarrero     
// Date: 9/14/23      
// Assignment: Lab 1
//----------------------------------------------------------------------//
//header file for the switch
#ifndef SWITCH_H
#define SWITCH_H
void initswitch(); //initialize the switch 
#endif
   
